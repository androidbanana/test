////////////////////////////////////////////////////////////
// EDIT PUZZLE
////////////////////////////////////////////////////////////
var edit = {show:true, option:'', isLandscape:true, strokeNum:0, strokeColor:'#FFA64D', gridSize:50, gridStroke:2, gridStrokeColor:'#26FFFF', gridArr:[], shapeColor:'#FF8000'};
var puzzleLoader, puzzleFileFest;

/*!
 * 
 * EDIT READY
 * 
 */
$(function() {
	$.editor.enable = true;
});

function loadEditPage(){
	optionsContainer.removeChild(buttonExit);

	puzzleEditStrokesContainer = new createjs.Container();
	puzzleEditGridContainer = new createjs.Container();
	puzzleEditGridContainer.alpha = .2;

	editDotStart = new createjs.Shape();	
	editDotStart.graphics.beginFill(edit.shapeColor).drawCircle(0, 0, gameSettings.dotRadius * 1.2);
	editDotEnd = new createjs.Shape();	
	editDotEnd.graphics.beginFill(edit.shapeColor).drawCircle(0, 0, gameSettings.dotRadius * 1.2);

	editDotStart.cursor = "pointer";
	editDotStart.strokeTarget = 0;
	editDotEnd.cursor = "pointer";
	editDotEnd.strokeTarget = 1;
	buildStrokeDrag(editDotStart);
	buildStrokeDrag(editDotEnd);

	puzzleEditContainer.addChild(puzzleEditGridContainer, puzzleEditStrokesContainer, editDotStart, editDotEnd);
	
	$.get('editTools.html', function(data){
		$('body').prepend(data);
		$('#editWrapper').show();
		toggleEditOption();
		buildEditButtons();
		buttonSettings.visible = false;
	});		
}

/*!
 * 
 * BUILD EDIT BUTTONS - This is the function that runs to build edit buttons
 * 
 */
function buildEditButtons(){
	$('#toggleShowOption').click(function(){
		toggleShowOption();
	});
	
	$("#viewport").change(function() {
		if($(this).val() != ''){
			if($(this).val() == 'true'){
				viewport.isLandscape = edit.isLandscape = true;	
			}else{
				viewport.isLandscape = edit.isLandscape = false;
			}
			
			changeViewport(viewport.isLandscape);
			resizeGameFunc();
		}
	});
	
	//puzzles list
	gameData.levelNum = 0;
	buildPuzzleDropdown();
	
	$('#togglePanel').click(function(){
		togglePanel();
	});
	
	$("#puzzlesList").change(function() {
		if($(this).val() != ''){
			gameData.levelNum = $(this).val();
			edit.strokeNum = 0;
			loadPuzzleData();
		}
	});
	
	$('#prevPuzzle').click(function(){
		togglePuzzle(false);
	});
	
	$('#nextPuzzle').click(function(){
		togglePuzzle(true);
	});
	
	$('#addPuzzle').click(function(){
		actionPuzzle('new');
	});
	
	$('#removePuzzle').click(function(){
		actionPuzzle('remove');
	});
	
	$('#movePuzzleUp').click(function(){
		actionPuzzle('moveup');
	});
	
	$('#movePuzzleDown').click(function(){
		actionPuzzle('movedown');
	});
	
	$('#editPuzzle').click(function(){
		toggleEditOption('strokes', true);
	});

	$('#strokeBack').click(function(){
		toggleEditOption();
	});

	//strokes
	$("#strokesList").change(function() {
		if($(this).val() != ''){
			edit.strokeNum = $(this).val();
			loadStrokeData();
			loadEditPuzzle();
		}
	});
	
	$('#prevStroke').click(function(){
		toggleStroke(false);
	});
	
	$('#nextStroke').click(function(){
		toggleStroke(true);
	});
	
	$('#addStroke').click(function(){
		actionStroke('new');
	});
	
	$('#removeStroke').click(function(){
		actionStroke('remove');
	});

	$('#updateStroke').click(function(){
		updateStroke();
		loadEditPuzzle();
	});

	$('#testPlay').click(function(){
		toggleEditOption('play');
	});

	$('#stopTestPlay').click(function(){
		toggleEditOption('stop');
	});
	
	//generate
	$('#generateArray').click(function(){
		generateArray();
	});

	togglePuzzle(false);
	togglePuzzle(true);
	updateEditGrid();
}

 /*!
 * 
 * TOGGLE DISPLAY OPTION - This is the function that runs to toggle display option
 * 
 */
 
function toggleShowOption(){
	if(edit.show){
		edit.show = false;
		$('#editOption').hide();
		$('#toggleShowOption').val('Show Edit Option');
	}else{
		edit.show = true;
		$('#editOption').show();
		$('#toggleShowOption').val('Hide Edit Option');
	}
}

/*!
 * 
 * TOGGLE EDIT OPTION - This is the function that runs to toggle edit option
 * 
 */
function toggleEditOption(con){
	edit.option = con;
	edit.option = edit.option == undefined ? "default" : edit.option;
	
	$('#editPuzzleWrapper').hide();
	$('#puzzleEditWrapper').hide();
	$('#hiddenEditWrapper').hide();
	$('#playWrapper').hide();
	puzzleStrokeContainer.visible = true;
	puzzleEditContainer.visible = false;

	if(con == 'strokes'){
		$('#puzzleEditWrapper').show();
		edit.strokeNum = 0;
		puzzleStrokeContainer.visible = false;
		puzzleEditContainer.visible = true;
	}else if(con == 'play'){
		$('#playWrapper').show();
		toggleGamePlay(true);
	}else if(con == 'stop'){
		toggleGamePlay(false);
		toggleEditOption();
	}else{
		$('#editPuzzleWrapper').show();
	}
}


/*!
 * 
 * BUILD PUZZLE DROPDOWN - This is the function that runs to build puzzle dropdown
 * 
 */
function buildPuzzleDropdown(){
	$('#puzzlesList').empty();
	for(n=0;n<levelSettings.length;n++){
		$('#puzzlesList').append($("<option/>", {
			value: n,
			text: 'Puzzle '+(n+1)
		}));
	}
	$('#puzzlesList').val(gameData.levelNum);
	
	loadPuzzleData();
}

/*!
 * 
 * TOGGLE PUZZLE - This is the function that runs to toggle puzzle
 * 
 */
function togglePuzzle(con){
	if(con){
		gameData.levelNum++;
		gameData.levelNum = gameData.levelNum > levelSettings.length - 1 ? 0 : gameData.levelNum;
	}else{
		gameData.levelNum--;
		gameData.levelNum = gameData.levelNum < 0 ? levelSettings.length - 1 : gameData.levelNum;
	}
	
	edit.strokeNum = 0;
	$('#puzzlesList').prop("selectedIndex", gameData.levelNum);
	loadPuzzleData();
}

/*!
 * 
 * LOAD EDITOR PUZZLE - This is the function that runs to load editor data
 * 
 */
function loadPuzzleData(){
	toggleEditOption();

	buildStrokeDropdown();
	loadStrokeData();
	loadEditPuzzle();
}

/*!
 * 
 * EDITOR ACTION - This is the function that runs to for editor action
 * 
 */
function actionPuzzle(action){
	switch(action){
		case 'new':
			levelSettings.push({
				strokes:[
					{sX:-100, sY:0, eX:100, eY:0},
				]
			});
			gameData.levelNum = levelSettings.length - 1;
			edit.strokeNum = 0;
			buildPuzzleDropdown();
		break;
		
		case 'remove':
			if(levelSettings.length > 1){
				levelSettings.splice(gameData.levelNum, 1);
				gameData.levelNum = 0;
				edit.strokeNum = 0;
				buildPuzzleDropdown();
			}
		break;
		
		case 'moveup':
			if(gameData.levelNum-1 >= 0){
				swapArray(levelSettings, gameData.levelNum-1, gameData.levelNum);
				gameData.levelNum--;
				buildPuzzleDropdown();
			}
		break;
		
		case 'movedown':
			if(gameData.levelNum+1 < levelSettings.length){
				swapArray(levelSettings, gameData.levelNum+1, gameData.levelNum);
				gameData.levelNum++;
				buildPuzzleDropdown();
			}
		break;
	}
}

/*!
 * 
 * UPDATE PUZZLE - This is the function that runs to update puzzle
 * 
 */
function updateStroke(){
	editDotStart.x = $('#strokeStartX').val();
	editDotStart.y = $('#strokeStartY').val();

	editDotEnd.x = $('#strokeEndX').val();
	editDotEnd.y = $('#strokeEndY').val();

	checkWithinArea(editDotStart);
	checkWithinArea(editDotEnd);

	$('#strokeStartX').val(editDotStart.x);
	$('#strokeStartY').val(editDotStart.y);
	$('#strokeEndX').val(editDotEnd.x);
	$('#strokeEndY').val(editDotEnd.y);
	
	levelSettings[gameData.levelNum].strokes[edit.strokeNum].sX = $('#strokeStartX').val();
	levelSettings[gameData.levelNum].strokes[edit.strokeNum].sY = $('#strokeStartY').val();
	levelSettings[gameData.levelNum].strokes[edit.strokeNum].eX = $('#strokeEndX').val();
	levelSettings[gameData.levelNum].strokes[edit.strokeNum].eY = $('#strokeEndY').val();
}

/*!
 * 
 * LOAD EDITOR PUZZLE - This is the function that runs to load editor data
 * 
 */
function loadStrokeData(){
	$('#strokeStartX').val(levelSettings[gameData.levelNum].strokes[edit.strokeNum].sX);
	$('#strokeStartY').val(levelSettings[gameData.levelNum].strokes[edit.strokeNum].sY);
	$('#strokeEndX').val(levelSettings[gameData.levelNum].strokes[edit.strokeNum].eX);
	$('#strokeEndY').val(levelSettings[gameData.levelNum].strokes[edit.strokeNum].eY);

	editDotStart.x = levelSettings[gameData.levelNum].strokes[edit.strokeNum].sX;
	editDotStart.y = levelSettings[gameData.levelNum].strokes[edit.strokeNum].sY;
	editDotEnd.x = levelSettings[gameData.levelNum].strokes[edit.strokeNum].eX;
	editDotEnd.y = levelSettings[gameData.levelNum].strokes[edit.strokeNum].eY;
}

/*!
 * 
 * BUILD PUZZLE DROPDOWN - This is the function that runs to build puzzle dropdown
 * 
 */
function buildStrokeDropdown(){
	$('#strokesList').empty();
	for(n=0;n<levelSettings[gameData.levelNum].strokes.length;n++){
		$('#strokesList').append($("<option/>", {
			value: n,
			text: 'Stroke '+(n+1)
		}));
	}
	$('#strokesList').val(edit.strokeNum);
	
	loadStrokeData();
}

/*!
 * 
 * EDITOR ACTION - This is the function that runs to for editor action
 * 
 */
function actionStroke(action){
	switch(action){
		case 'new':
			levelSettings[gameData.levelNum].strokes.push({sX:-100, sY:0, eX:100, eY:0});
			edit.strokeNum = levelSettings[gameData.levelNum].strokes.length - 1;
			
			buildStrokeDropdown();
			loadStrokeData();
			loadEditPuzzle();
		break;
		
		case 'remove':
			if(levelSettings[gameData.levelNum].strokes.length > 1){
				levelSettings[gameData.levelNum].strokes.splice(edit.strokeNum, 1);
				edit.strokeNum = 0;
				buildStrokeDropdown();
				loadStrokeData();
				loadEditPuzzle();
			}
		break;
	}
}

/*!
 * 
 * TOGGLE STROKE - This is the function that runs to toggle strokes
 * 
 */
function toggleStroke(con){
	if(con){
		edit.strokeNum++;
		edit.strokeNum = edit.strokeNum > levelSettings[gameData.levelNum].strokes.length - 1 ? 0 : edit.strokeNum;
	}else{
		edit.strokeNum--;
		edit.strokeNum = edit.strokeNum < 0 ? levelSettings[gameData.levelNum].strokes.length - 1 : edit.strokeNum;
	}
	
	$('#strokesList').prop("selectedIndex", edit.strokeNum);
	loadStrokeData();
	loadEditPuzzle();
}

/*!
 * 
 * LOAD EDIT PUZZLE - This is the function that runs to load edit puzzle
 * 
 */
function loadEditPuzzle(){
	preparePuzzle();
	updateEditStrokes();
}


/*!
 * 
 * UPDATE GRID AND STROKES - This is the function that runs to update grid and strokes
 * 
 */
function updateEditGrid(){
	var posData = {x:0, y:0, sX:0, sY:0, col:10, row:10, colCount:0};
	posData.sX = -((posData.col * edit.gridSize)/2);
	posData.sY = -((posData.row * edit.gridSize)/2);
	posData.x = posData.sX;
	posData.y = posData.sY;

	for(var n=0; n<posData.col * posData.row; n++){
		var newGrid = new createjs.Shape();
		newGrid.graphics.setStrokeStyle(edit.gridStroke).beginStroke(edit.gridStrokeColor).drawRect(0, 0, edit.gridSize, edit.gridSize);
		newGrid.x = posData.x;
		newGrid.y = posData.y;

		edit.gridArr.push({x:posData.x, y:posData.y});
		puzzleEditGridContainer.addChild(newGrid);

		posData.x += edit.gridSize;
		posData.colCount++;
		if(posData.colCount >= posData.col){
			edit.gridArr.push({x:posData.x, y:posData.y});
			posData.colCount = 0;
			posData.x = posData.sX;
			posData.y += edit.gridSize;
		}
	}

	for(var n=0; n<posData.col; n++){
		edit.gridArr.push({x:posData.x, y:posData.y});
		posData.x += edit.gridSize;

		if(n == posData.col-1){
			edit.gridArr.push({x:posData.x, y:posData.y});
		}
	}
}

function updateEditStrokes(){
	puzzleEditStrokesContainer.removeAllChildren();

	for(var n=0; n<levelSettings[gameData.levelNum].strokes.length; n++){
		var strokeColor = edit.strokeColor;

		$.puzzle[n+'editStroke'] = new createjs.Shape();
		$.puzzle[n+'editStroke'].graphics.ss(gameSettings.strokeSize, "round").s(strokeColor);
		$.puzzle[n+'editStroke'].graphics.mt(levelSettings[gameData.levelNum].strokes[n].sX, levelSettings[gameData.levelNum].strokes[n].sY);        
		$.puzzle[n+'editStroke'].graphics.lt(levelSettings[gameData.levelNum].strokes[n].eX, levelSettings[gameData.levelNum].strokes[n].eY);

		$.puzzle[n+'editStroke'].alpha = .5;
		$.puzzle[n+'editStroke'].strokeIndex = n;
		$.puzzle[n+'editStroke'].cursor = "pointer";
		$.puzzle[n+'editStroke'].addEventListener("click", function(evt) {
			edit.strokeNum = evt.target.strokeIndex;
			$('#strokesList').val(edit.strokeNum);
			loadStrokeData();
			updateEditStrokes();
		});

		if(edit.strokeNum == n){
			$.puzzle[n+'editStroke'].alpha = 1;
		}

		puzzleEditStrokesContainer.addChild($.puzzle[n+'editStroke']);
	}
}

/*!
 * 
 * GENERATE ARRAY - This is the function that runs to generate array
 * 
 */
function generateArray(){
	var outputArray = '';
	var space = '					';
	var space2 = '						';
	var space3 = '							';
	var space4 = '								';
	
	outputArray += "[\n";
	for(e=0;e<levelSettings.length;e++){
		var strokesArray = '';
		for(var l=0; l < levelSettings[e].strokes.length; l++){
			strokesArray += space3+"{sX:"+levelSettings[e].strokes[l].sX+", sY:"+levelSettings[e].strokes[l].sY+", eX:"+levelSettings[e].strokes[l].eX+", eY:"+levelSettings[e].strokes[l].eY+",},\n";
		}

		outputArray += space+"{\n";
		outputArray += space2+"strokes:[\n";
		outputArray += strokesArray;
		outputArray += space2+"],\n";
		outputArray += space+"},\n";
	}
						
	outputArray += '];';
	outputArray = outputArray.replace(/undefined/g,0);
	$('#outputArray').val(outputArray);	
}

 /*!
 * 
 * SETUP BG EVENTS - This is the function that runs to setup bg events
 * 
 */
 function buildStrokeDrag(obj){
	removeColorEvents(obj);

	obj.addEventListener("mousedown", function(evt) {
		toggleStrokeEvent(evt, 'drag')
	});
	obj.addEventListener("pressmove", function(evt) {
		toggleStrokeEvent(evt, 'move')
	});
	obj.addEventListener("pressup", function(evt) {
		toggleStrokeEvent(evt, 'release');
	});
}

function removeColorEvents(obj){
	obj.removeAllEventListeners("mousedown");
	obj.removeAllEventListeners("pressmove");
	obj.removeAllEventListeners("pressup");
}

function toggleStrokeEvent(obj, con){
	if(edit.option == 'default'){
		return;
	}

	switch(con){
		case 'drag':
			obj.target.offset = {x:obj.target.x-(obj.stageX), y:obj.target.y-(obj.stageY)};
			loadStrokeData();
			checkWithinArea(obj.target);
		break;
		
		case 'move':
			obj.target.x = (obj.stageX) + obj.target.offset.x;
			obj.target.y = (obj.stageY) + obj.target.offset.y;

			for(var n=0; n<edit.gridArr.length; n++){
				var thisDistance = getDistance(obj.target.x, obj.target.y, edit.gridArr[n].x, edit.gridArr[n].y);
				if(thisDistance <= edit.gridSize/5){
					obj.target.x = Math.floor(edit.gridArr[n].x);
					obj.target.y = Math.floor(edit.gridArr[n].y);
				}
			}
			checkWithinArea(obj.target);

			if(obj.target.strokeTarget == 0){
				$('#strokeStartX').val(Math.floor(obj.target.x));
				$('#strokeStartY').val(Math.floor(obj.target.y));

				$.puzzle[edit.strokeNum+'start'].x = $('#strokeStartX').val();
				$.puzzle[edit.strokeNum+'start'].y = $('#strokeStartY').val();

				levelSettings[gameData.levelNum].strokes[edit.strokeNum].sX = $('#strokeStartX').val();
				levelSettings[gameData.levelNum].strokes[edit.strokeNum].sY = $('#strokeStartY').val();
			}else{
				$('#strokeEndX').val(Math.floor(obj.target.x));
				$('#strokeEndY').val(Math.floor(obj.target.y));

				$.puzzle[edit.strokeNum+'end'].x = $('#strokeEndX').val();
				$.puzzle[edit.strokeNum+'end'].y = $('#strokeEndY').val();

				levelSettings[gameData.levelNum].strokes[edit.strokeNum].eX = $('#strokeEndX').val();
				levelSettings[gameData.levelNum].strokes[edit.strokeNum].eY = $('#strokeEndY').val();
			}
			updateEditStrokes();
		break;
		
		case 'release':
			preparePuzzle();
		break;
	}
}

function checkWithinArea(obj){
	var drawGuideSize = 10;
	var startX = -(gameData.drawGuideW/2 - (gameSettings.dotRadius + (drawGuideSize/2)));
	var endX = (gameData.drawGuideW/2 - (gameSettings.dotRadius + (drawGuideSize/2)));
	if(obj.x <= startX){
		obj.x = startX;
	}else if(obj.x >= endX){
		obj.x = endX;
	}

	var startY = -(gameData.drawGuideH/2 - (gameSettings.dotRadius + (drawGuideSize/2)));
	var endY = (gameData.drawGuideH/2 - (gameSettings.dotRadius + (drawGuideSize/2)));
	if(obj.y <= startY){
		obj.y = startY;
	}else if(obj.y >= endY){
		obj.y = endY;
	}
}

/*!
 * 
 * TOGGLE GAME PLAY - This is the function that runs to toggle game play
 * 
 */
function toggleGamePlay(con){
	if(con){
		toggleGameStatus('Game start:');
		stopGame();
		preparePuzzle();
	}else{
		stopGame();
		loadPuzzleData();
	}
}

function toggleGameStatus(text){
	$('#gameStatus').html(text);
}