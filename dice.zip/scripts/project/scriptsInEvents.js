


const scriptsInEvents = {

	async Gameplayevent_Event142_Act1(runtime, localVars)
	{
		console.log("fasfd")
	},

	async Gameplayevent_Event178_Act1(runtime, localVars)
	{
		
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

