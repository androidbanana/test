////////////////////////////////////////////////////////////
// GAME v1.1
////////////////////////////////////////////////////////////

/*!
 * 
 * GAME SETTING CUSTOMIZATION START
 * 
 */

//game settings
var gameSettings = {
	colors:[
		{guide:'#CCCCCC', drawStroke:'#ff0613', drawDot:'#c42a2a', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#83d821', drawDot:'#64a511', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#8848ed', drawDot:'#5923af', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#4fc0e8', drawDot:'#3d99d8', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#1c7df2', drawDot:'#174aaf', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#28d1a9', drawDot:'#17968a', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#eb86be', drawDot:'#cc2364', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#636c77', drawDot:'#424852', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#e3b692', drawDot:'#c17a49', completeStroke:'#ff8908', completeDot:'#e86e0a'},
		{guide:'#CCCCCC', drawStroke:'#f5b945', drawDot:'#ce9436', completeStroke:'#ff8908', completeDot:'#e86e0a'},
	],
	dotRadius:20,
	strokeSize:15,
};

//game text display
var textDisplay = {
	selectLevel:'SELECT LEVEL',
	exitTitle:'EXIT GAME',
	exitMessage:'ARE YOU SURE\nYOU WANT TO\nQUIT GAME?',
	share:'',
	resultTitle:'You Win!',
	resultComplete:'COMPLETE',
	resultDesc:'LEVEL [NUMBER]',
}

//Social share, [SCORE] will replace with game score
var shareEnable = true; //toggle share
var shareTitle = 'Highscore on One Stroke is Level [SCORE]';//social share score title
var shareMessage = 'Level [SCORE] is mine new highscore on One Stroke game! Try it now!'; //social share score message


/*!
 *
 * GAME SETTING CUSTOMIZATION END
 *
 */
$.editor = {enable:false};
var playerData = {score:0};
var gameData = {paused:true, levelNum:0, colors:[], colorIndex:0, strokeData:{x:0, y:0}, drawGuideW:600, drawGuideH:600, levelCompleted:1};
var tweenData = {score:0, tweenScore:0};
var timeData = {enable:false, startDate:null, nowDate:null, timer:0, oldTimer:0};
var selectData = {page:0, total:1, max:20, column:5, row:4};
var cookieName = 'colorlink2024';

/*!
 * 
 * DATA UPDATE - This is the function that runs to update data
 * 
 */
function retrieveLevelData(){
	var curLevel = Cookies.get(cookieName);
	if(curLevel != undefined){
		gameData.levelCompleted = Number(curLevel);
		gameData.levelCompleted = gameData.levelCompleted >= levelSettings.length ? levelSettings.length : gameData.levelCompleted;
		findSelectPage(gameData.levelCompleted);
	}
}

function saveLevelData(){
	if(Number(gameData.levelNum) >= gameData.levelCompleted){
		gameData.levelCompleted = Number(gameData.levelNum)+1;
		gameData.levelCompleted = gameData.levelCompleted >= levelSettings.length ? levelSettings.length : gameData.levelCompleted;
		Cookies.set(cookieName, gameData.levelCompleted, {expires:360});
	}
}

/*!
 * 
 * GAME BUTTONS - This is the function that runs to setup button event
 * 
 */
function buildGameButton(){
	$(window).focus(function() {
		if(!buttonSoundOn.visible){
			toggleSoundInMute(false);
		}

		if (typeof buttonMusicOn != "undefined") {
			if(!buttonMusicOn.visible){
				toggleMusicInMute(false);
			}
		}
	});
	
	$(window).blur(function() {
		if(!buttonSoundOn.visible){
			toggleSoundInMute(true);
		}

		if (typeof buttonMusicOn != "undefined") {
			if(!buttonMusicOn.visible){
				toggleMusicInMute(true);
			}
		}
	});
	
	if($.browser.mobile || isTablet){

	}else{
		
	}

	buttonStart.cursor = "pointer";
	buttonStart.addEventListener("click", function(evt) {
		playSound('soundButton');
		goPage('level');
	});

	buttonLevelArrowL.cursor = "pointer";
	buttonLevelArrowL.addEventListener("click", function(evt) {
		playSound('soundButton');
		toggleSelect(false);
	});

	buttonLevelArrowR.cursor = "pointer";
	buttonLevelArrowR.addEventListener("click", function(evt) {
		playSound('soundButton');
		toggleSelect(true);
	});
	
	itemExit.addEventListener("click", function(evt) {
	});
	
	buttonContinue.cursor = "pointer";
	buttonContinue.addEventListener("click", function(evt) {
		playSound('soundButton');
		goPage('level');
	});
	
	buttonFacebook.cursor = "pointer";
	buttonFacebook.addEventListener("click", function(evt) {
		share('facebook');
	});
	
	buttonTwitter.cursor = "pointer";
	buttonTwitter.addEventListener("click", function(evt) {
		share('twitter');
	});
	buttonWhatsapp.cursor = "pointer";
	buttonWhatsapp.addEventListener("click", function(evt) {
		share('whatsapp');
	});
	
	buttonSoundOff.cursor = "pointer";
	buttonSoundOff.addEventListener("click", function(evt) {
		toggleSoundMute(true);
	});
	
	buttonSoundOn.cursor = "pointer";
	buttonSoundOn.addEventListener("click", function(evt) {
		toggleSoundMute(false);
	});

	if (typeof buttonMusicOff != "undefined") {
		buttonMusicOff.cursor = "pointer";
		buttonMusicOff.addEventListener("click", function(evt) {
			toggleMusicMute(true);
		});
	}
	
	if (typeof buttonMusicOn != "undefined") {
		buttonMusicOn.cursor = "pointer";
		buttonMusicOn.addEventListener("click", function(evt) {
			toggleMusicMute(false);
		});
	}
	
	buttonFullscreen.cursor = "pointer";
	buttonFullscreen.addEventListener("click", function(evt) {
		toggleFullScreen();
	});
	
	buttonExit.cursor = "pointer";
	buttonExit.addEventListener("click", function(evt) {
		togglePop(true);
		toggleOption();
	});
	
	buttonSettings.cursor = "pointer";
	buttonSettings.addEventListener("click", function(evt) {
		toggleOption();
	});
	
	buttonConfirm.cursor = "pointer";
	buttonConfirm.addEventListener("click", function(evt) {
		playSound('soundButton');
		togglePop(false);
		
		stopGame();
		goPage('main');
	});
	
	buttonCancel.cursor = "pointer";
	buttonCancel.addEventListener("click", function(evt) {
		playSound('soundButton');
		togglePop(false);
	});

	buttonRetry.cursor = "pointer";
	buttonRetry.addEventListener("click", function(evt) {
		resetStrokes(true);
	});

	buttonUndo.cursor = "pointer";
	buttonUndo.addEventListener("click", function(evt) {
		undoStrokes();
	});

	for(var n=0; n<gameSettings.colors.length; n++){
		gameData.colors.push(n);
	}
	shuffle(gameData.colors);

	setupStageEvents();
	buildSelectLevel();
}

/*!
 * 
 * SELECT LEVEL - This is the function that runs to display select levels
 * 
 */
function buildSelectLevel(){
	selectData.total = levelSettings.length/selectData.max;
	
	if (String(selectData.total).indexOf('.') > -1){
		selectData.total=Math.floor(selectData.total)+1;
	}
	toggleSelect(false);
	for(var r=0; r<selectData.row; r++){
		for(var c=0; c<selectData.column; c++){
			$.level[r+'_unlock_'+c].cursor = "pointer";
			$.level[r+'_unlock_'+c].addEventListener("click", function(evt) {
				gameData.levelNum = Number(evt.target.text.text) - 1;
				playSound('soundButton');
				goPage("game");
			});
		}
	}
}

function toggleSelect(con){
	if(con){
		selectData.page++;
		selectData.page = selectData.page > selectData.total ? selectData.total : selectData.page;
	}else{
		selectData.page--;
		selectData.page = selectData.page < 1 ? 1 : selectData.page;
	}
	selectPage(selectData.page);
}

function selectPage(num){
	selectData.page = num;
	selectData.page = selectData.page < 1 ? 1 : selectData.page;
	
	var startNum = (selectData.page-1) * selectData.max;
	for(var r=0; r<selectData.row; r++){
		for(var c=0; c<selectData.column; c++){
			$.level[r+'_unlock_'+c].visible = false;
			if(startNum < levelSettings.length){
				$.level[r+'_text_'+c].text = startNum+1;
				$.level[r+'_unlock_'+c].text.visible = true;
				$.level[r+'_'+c].visible = true;
			}else{
				$.level[r+'_'+c].visible = false;
				$.level[r+'_unlock_'+c].text.visible = false;
			}

			if((startNum) < gameData.levelCompleted){
				if(gameData.revealLevel && (gameData.levelNum+1) == $.level[r+'_text_'+c].text){
					unlockLevelTween(r,c);
				}else{
					$.level[r+'_unlock_'+c].visible = true;
				}
			}else{
				$.level[r+'_text_'+c].text = '';
			}
			startNum++;
		}
	}
	
	if(selectData.page == 1){
		buttonLevelArrowL.visible = false;
	}else{
		buttonLevelArrowL.visible = true;
	}
	
	if(selectData.page == selectData.total || selectData.total == 1){
		buttonLevelArrowR.visible = false;
	}else{
		buttonLevelArrowR.visible = true;
	}
}

function unlockLevelTween(r,c){
	gameData.revealLevel = false;
	$.level[r+'_unlock_'+c].visible = true;
	$.level[r+'_unlock_'+c].alpha = 0;
	$.level[r+'_text_'+c].alpha = 0;

	TweenMax.to($.level[r+'_unlock_'+c], .5, {delay:.5, alpha:1, scaleX:1.2, scaleY:1.2, overwrite:true, onStart:function(){
		playSound('soundUnlock');
	}, onComplete:function(){
		TweenMax.to($.level[r+'_unlock_'+c], .5, {scaleX:1, scaleY:1, overwrite:true});
	}});
	TweenMax.to($.level[r+'_text_'+c], .5, {delay:.5, alpha:1, overwrite:true});
}

function findSelectPage(level){
	for(var n=0; n<10; n++){
		var startNum = (n+1) * selectData.max;
		if(level <= startNum){
			selectData.page = n+1;
			n = 10;
		}
	}
}

/*!
 * 
 * TOGGLE POP - This is the function that runs to toggle popup overlay
 * 
 */
function togglePop(con){
	confirmContainer.visible = con;
}


/*!
 * 
 * DISPLAY PAGES - This is the function that runs to display pages
 * 
 */
var curPage=''
function goPage(page){
	curPage=page;
	
	mainContainer.visible = false;
	levelContainer.visible = false;
	gameContainer.visible = false;
	resultContainer.visible = false;
	
	var targetContainer = null;
	switch(page){
		case 'main':
			targetContainer = mainContainer;
			stopMusicLoop('musicGame');
			playMusicLoop('musicMain');

		break;

		case 'level':
			targetContainer = levelContainer;
			selectPage(selectData.page);
		break;
		
		case 'game':
			targetContainer = gameContainer;
			if(!$.editor.enable){
				stopMusicLoop('musicMain');
				playMusicLoop('musicGame');
			}

			startGame();
		break;
		
		case 'result':
			targetContainer = resultContainer;
			stopGame();
			togglePop(false);

			stopMusicLoop('musicGame');
			playSound('soundResult');
			
			playerData.score = gameData.levelNum;
			resultDescTxt.text = textDisplay.resultDesc.replace('[NUMBER]', gameData.levelNum)
			
			saveGame(playerData.score);
		break;
	}
	
	if(targetContainer != null){
		targetContainer.visible = true;
		targetContainer.alpha = 0;
		TweenMax.to(targetContainer, .5, {alpha:1, overwrite:true});
	}
	
	resizeCanvas();
}

/*!
 * 
 * START GAME - This is the function that runs to start game
 * 
 */
function startGame(){
	gameData.paused = false;

	if(!$.editor.enable){
		preparePuzzle();
		playSound('soundStart');
	}
}

function resizePuzzle(){
	levelContainer.x = canvasW/2;
	levelContainer.y = canvasH/2;

	puzzleContainer.x = canvasW/2;
	puzzleContainer.y = canvasH/2;

	scoreContainer.x = offset.x + 40;
	scoreContainer.y = offset.y + 30;

	buttonRetry.x = canvasW/100 * 86;
	buttonRetry.y = canvasH/2 + 40;

	buttonUndo.x = canvasW/100 * 86;
	buttonUndo.y = canvasH/2 - 40;

	buttonLevelArrowL.x = -260;
	buttonLevelArrowR.x = 260;

	if(viewport.isLandscape){
		selectLevelTitleTxt.y = -(canvasH/100 * 25);
	}else{
		selectLevelTitleTxt.y = -(canvasH/100 * 25);
		buttonRetry.x = canvasW/2 + 40;
		buttonRetry.y = canvasH/100*85;

		buttonUndo.x = canvasW/2 - 40;
		buttonUndo.y = canvasH/100*85;
	}
}

 /*!
 * 
 * STOP GAME - This is the function that runs to stop play game
 * 
 */
function stopGame(){	
	gameData.paused = true;
	TweenMax.killAll(false, true, false);
}

function saveGame(score){
	if ( typeof toggleScoreboardSave == 'function' ) { 
		$.scoreData.score = score;
		if(typeof type != 'undefined'){
			$.scoreData.type = type;	
		}
		toggleScoreboardSave(true);
	}

	/*$.ajax({
      type: "POST",
      url: 'saveResults.php',
      data: {score:score},
      success: function (result) {
          console.log(result);
      }
    });*/
}

/*!
 * 
 * LOAD PUZZLE - This is the function that runs to load puzzle
 * 
 */
function preparePuzzle(){
	gameData.drawing = false;
	gameData.complete = false;

	puzzleGuideContainer.removeAllChildren();
	puzzleAnimateContainer.removeAllChildren();
	puzzleStrokeContainer.removeAllChildren();
	puzzleDotContainer.removeAllChildren();
	
	var gamePlay = true;
	buttonRetry.visible = true;
	buttonUndo.visible = true;
	scoreContainer.visible = true;

	if($.editor.enable){
		if(edit.option != 'play'){
			gamePlay = false;
			buttonRetry.visible = false;
			buttonUndo.visible = false;
			scoreContainer.visible = false;
		}
	}
	gameData.strokes = [];
	gameData.shapeIndex = [];
	gameData.strokesHistory = [];
	
	for(var n=0; n<levelSettings[gameData.levelNum].strokes.length; n++){
		gameData.strokes.push({index:n, complete:false, sX:levelSettings[gameData.levelNum].strokes[n].sX, sY:levelSettings[gameData.levelNum].strokes[n].sY, eX:levelSettings[gameData.levelNum].strokes[n].eX, eY:levelSettings[gameData.levelNum].strokes[n].eY});

		var colorIndex = gameData.colors[gameData.colorIndex];
		var strokeColor = gameSettings.colors[colorIndex].guide;
		var dotColor = gameSettings.colors[colorIndex].drawDot;

		$.puzzle[n+'start'] = new createjs.Shape();
		$.puzzle[n+'start'].graphics.beginFill(dotColor).drawCircle(0, 0, gameSettings.dotRadius);
		$.puzzle[n+'start'].x = levelSettings[gameData.levelNum].strokes[n].sX;
		$.puzzle[n+'start'].y = levelSettings[gameData.levelNum].strokes[n].sY;

		$.puzzle[n+'end'] = new createjs.Shape();
		$.puzzle[n+'end'].graphics.beginFill(dotColor).drawCircle(0, 0, gameSettings.dotRadius);
		$.puzzle[n+'end'].x = levelSettings[gameData.levelNum].strokes[n].eX;
		$.puzzle[n+'end'].y = levelSettings[gameData.levelNum].strokes[n].eY;

		if(gamePlay){
			$.puzzle[n+'start'].cursor = "pointer";
			$.puzzle[n+'start'].addEventListener("mousedown", function(evt) {
				addStroke(evt.target.x, evt.target.y);
			});

			$.puzzle[n+'end'].cursor = "pointer";
			$.puzzle[n+'end'].addEventListener("mousedown", function(evt) {
				addStroke(evt.target.x, evt.target.y);
			});
		}

		$.puzzle[n+'stroke'] = new createjs.Shape();
		$.puzzle[n+'stroke'].graphics.ss(gameSettings.strokeSize, "round").s(strokeColor);
		$.puzzle[n+'stroke'].graphics.mt(levelSettings[gameData.levelNum].strokes[n].sX, levelSettings[gameData.levelNum].strokes[n].sY);        
		$.puzzle[n+'stroke'].graphics.lt(levelSettings[gameData.levelNum].strokes[n].eX, levelSettings[gameData.levelNum].strokes[n].eY);

		puzzleGuideContainer.addChild($.puzzle[n+'stroke']);
		puzzleDotContainer.addChild($.puzzle[n+'start'], $.puzzle[n+'end']);
	}

	updateScore();
}

/*!
 * 
 * STAGE EVENTS - This is the function that runs to build stage events
 * 
 */
function setupStageEvents(){
	stage.addEventListener("mousedown", function(evt) {
		toggleStageEvent(evt, 'down')
	});
	
	stage.addEventListener("pressmove", function(evt) {
		toggleStageEvent(evt, 'move')
	});

	stage.addEventListener("pressup", function(evt) {
		toggleStageEvent(evt, 'release')
	});
}

function removeStageEvents(){
	stage.removeAllEventListeners("mousedown");
	stage.removeAllEventListeners("pressmove");
	stage.removeAllEventListeners("pressup");
}

/*!
 * 
 * TOGGLE STEGE EVENTS - This is the function that runs to toggle stage events
 * 
 */
function toggleStageEvent(obj, con){
	switch(con){
		case 'down':

		break;

		case 'move':
			if (gameData.drawing) {
				updateStrokeDrawing();
			}
		break;
		
		case 'release':
			if (gameData.drawing) {
				timeData.startDate = new Date();
				removeStroke();
			}
		break;
	}
}

/*!
 * 
 * DRWAING GUIDE - This is the function that runs to follow drawing guide
 * 
 */

function addStroke(x,y){
	if(gameData.complete){
		return;
	}

	var proceedStroke = true;
	if(gameData.strokesHistory.length != 0){
		if(x == gameData.strokesHistory[gameData.strokesHistory.length-1].eX && y == gameData.strokesHistory[gameData.strokesHistory.length-1].eY){
			
		}else{
			proceedStroke = false;
		}
	}

	if(proceedStroke){
		playSound('soundSelect');
		animateDot(x,y, false);
		gameData.drawing = true;

		gameData.strokeData.x = x;
		gameData.strokeData.y = y;
		
		$.puzzle[gameData.shapeIndex] = new createjs.Shape();
		puzzleStrokeContainer.addChild($.puzzle[gameData.shapeIndex]);
	}else{
		playSound('soundError');
	}
}

function updateStrokeDrawing(){
	var movePos = puzzleContainer.globalToLocal(stage.mouseX, stage.mouseY);
	var drawGuideSize = 10;
	movePos.x = movePos.x <= -(gameData.drawGuideW/2 - drawGuideSize) ? -(gameData.drawGuideW/2 - drawGuideSize) : movePos.x;
	movePos.x = movePos.x >= (gameData.drawGuideW/2 - drawGuideSize) ? (gameData.drawGuideW/2 - drawGuideSize) : movePos.x;
	movePos.y = movePos.y <= -(gameData.drawGuideH/2 - drawGuideSize) ? -(gameData.drawGuideH/2 - drawGuideSize) : movePos.y;
	movePos.y = movePos.y >= (gameData.drawGuideH/2 - drawGuideSize) ? (gameData.drawGuideH/2 - drawGuideSize) : movePos.y;

	drawStroke(movePos.x, movePos.y);
	for(var n=0; n<gameData.strokes.length; n++){
		if(!gameData.strokes[n].complete){	
			if(gameData.strokeData.x == gameData.strokes[n].sX && gameData.strokeData.y == gameData.strokes[n].sY){
				var checkDistance = getDistance(movePos.x, movePos.y, gameData.strokes[n].eX, gameData.strokes[n].eY);
				if(checkDistance <= gameSettings.dotRadius){
					gameData.strokes[n].complete = true;
					drawStroke(gameData.strokes[n].eX, gameData.strokes[n].eY);
					gameData.shapeIndex++;
					gameData.strokesHistory.push({index:n, shape:gameData.shapeIndex, sX:gameData.strokeData.x, sY:gameData.strokeData.y, eX:gameData.strokes[n].eX, eY:gameData.strokes[n].eY});
					addStroke(gameData.strokes[n].eX, gameData.strokes[n].eY);
					checkPuzzleComplete();
				}
			}
			if(gameData.strokeData.x == gameData.strokes[n].eX && gameData.strokeData.y == gameData.strokes[n].eY){
				var checkDistance = getDistance(movePos.x, movePos.y, gameData.strokes[n].sX, gameData.strokes[n].sY);
				if(checkDistance <= gameSettings.dotRadius){
					gameData.strokes[n].complete = true;
					drawStroke(gameData.strokes[n].sX, gameData.strokes[n].sY);
					gameData.shapeIndex++;
					gameData.strokesHistory.push({index:n, shape:gameData.shapeIndex, sX:gameData.strokeData.x, sY:gameData.strokeData.y, eX:gameData.strokes[n].sX, eY:gameData.strokes[n].sY});
					addStroke(gameData.strokes[n].sX, gameData.strokes[n].sY);
					checkPuzzleComplete();
				}
			}
		}
	}
}

function drawStroke(x,y){
	var colorIndex = gameData.colors[gameData.colorIndex];
	var strokeColor = gameSettings.colors[colorIndex].drawStroke;

	$.puzzle[gameData.shapeIndex].graphics.clear();
	$.puzzle[gameData.shapeIndex].graphics.ss(gameSettings.strokeSize, "round").s(strokeColor);
	$.puzzle[gameData.shapeIndex].graphics.mt(gameData.strokeData.x, gameData.strokeData.y);        
	$.puzzle[gameData.shapeIndex].graphics.lt(x, y);
}

function removeStroke(){
	gameData.drawing = false;
	puzzleStrokeContainer.removeChild($.puzzle[gameData.shapeIndex]);
}

/*!
 * 
 * STROKE EVENTS - This is the function that runs for stroke events
 * 
 */
function undoStrokes(){
	if(gameData.complete){
		return;
	}

	playSound('soundUndo');
	if(gameData.strokesHistory.length == 1){
		resetStrokes(false);
	}else if(gameData.strokesHistory.length > 0){
		var historyIndex = gameData.strokesHistory.length-1;
		puzzleStrokeContainer.removeChild($.puzzle[historyIndex]);

		gameData.strokes[gameData.strokesHistory[historyIndex].index].complete = false;
		gameData.strokesHistory.splice(historyIndex,1);
		gameData.shapeIndex = gameData.strokesHistory.length;
	}
	updateScore();
}

function resetStrokes(sound){
	if(gameData.complete){
		return;
	}

	if(sound){
		playSound('soundReset');
	}
	gameData.drawing = false;
	puzzleStrokeContainer.removeAllChildren();
	gameData.shapeIndex = 0;
	gameData.strokesHistory = [];
	
	for(var n=0; n<gameData.strokes.length; n++){
		gameData.strokes[n].complete = false;
	}
	updateScore();
}

/*!
 * 
 * CHECK PUZZLE COMPLETE - This is the function that runs to check puzzle complete
 * 
 */
function checkPuzzleComplete(){
	updateScore();
	var puzzleComplete = 0;
	for(var n=0; n<gameData.strokes.length; n++){
		if(gameData.strokes[n].complete){
			puzzleComplete++;
		}
	}

	if(puzzleComplete == gameData.strokes.length){
		gameData.complete = true;
		buttonRetry.visible = false;
		buttonUndo.visible = false;

		gameData.loopStrokeIndex = 0;
		loopCompleteStroke();
	}else{
		var isPlayable = false;
		var lastHistoryIndex = gameData.strokesHistory.length-1;
		for(var n=0; n<gameData.strokes.length; n++){
			var isMatched = false;
			if(gameData.strokesHistory[lastHistoryIndex].eX == gameData.strokes[n].sX && gameData.strokesHistory[lastHistoryIndex].eY == gameData.strokes[n].sY){
				isMatched = true;
			}
			if(gameData.strokesHistory[lastHistoryIndex].eX == gameData.strokes[n].eX && gameData.strokesHistory[lastHistoryIndex].eY == gameData.strokes[n].eY){
				isMatched = true;
			}
			if(isMatched){
				if(!gameData.strokes[n].complete){
					isPlayable = true;
				}
			}
		}
		if(!isPlayable){
			resetStrokes(true);
		}
	}
}

function loopCompleteStroke(){
	if(gameData.loopStrokeIndex < gameData.strokesHistory.length){
		var colorIndex = gameData.colors[gameData.colorIndex];
		var strokeColor = gameSettings.colors[colorIndex].completeStroke;

		var newStroke = new createjs.Shape();
		puzzleAnimateContainer.addChild(newStroke);

		var startX = gameData.strokesHistory[gameData.loopStrokeIndex].sX;
		var startY = gameData.strokesHistory[gameData.loopStrokeIndex].sY;
		var nextX = gameData.strokesHistory[gameData.loopStrokeIndex].eX;
		var nextY = gameData.strokesHistory[gameData.loopStrokeIndex].eY;		
		var moveData = {x:startX, y:startY};

		playSound('soundStroke');
		TweenMax.to(moveData, .2, {x:nextX, y:nextY, overwrite:true, onUpdate:function(){
			newStroke.graphics.clear();
			newStroke.graphics.ss(gameSettings.strokeSize, "round").s(strokeColor);
			newStroke.graphics.mt(startX, startY);        
			newStroke.graphics.lt(moveData.x, moveData.y);
		}, onComplete:function(){
			gameData.loopStrokeIndex++;
			loopCompleteStroke();
		}});
	}else{
		updateScore();
		for(var n=0; n<levelSettings[gameData.levelNum].strokes.length; n++){
			var colorIndex = gameData.colors[gameData.colorIndex];
			var dotColor = gameSettings.colors[colorIndex].completeDot;

			$.puzzle[n+'start'].graphics.clear().beginFill(dotColor).drawCircle(0, 0, gameSettings.dotRadius);
			$.puzzle[n+'end'].graphics.clear().beginFill(dotColor).drawCircle(0, 0, gameSettings.dotRadius);
			
			animateDot($.puzzle[n+'start'].x, $.puzzle[n+'start'].y, true);
			animateDot($.puzzle[n+'end'].x, $.puzzle[n+'end'].y, true);
		}
		if(!$.editor.enable){
			endGame();
		}
	}
}

/*!
 * 
 * ANIMATE SHAPE - This is the function that runs to animate shape
 * 
 */
function animateDot(x,y,complete){
	var colorIndex = gameData.colors[gameData.colorIndex];
	var dotColor = complete == true ? gameSettings.colors[colorIndex].completeDot : gameSettings.colors[colorIndex].drawDot;

	var newShape = new createjs.Shape();
	newShape.graphics.beginFill(dotColor).drawCircle(0, 0, gameSettings.dotRadius);
	newShape.x = x;
	newShape.y = y;
	puzzleAnimateContainer.addChild(newShape);

	TweenMax.to(newShape, .5, {scaleX:3, scaleY:3, alpha:0, overwrite:true, onComplete:function(){
		puzzleAnimateContainer.removeChild(newShape);
	}});
}

function updateScore(){
	scoreTxt.text = gameData.strokesHistory.length+'/'+gameData.strokes.length;

	var colorIndex = gameData.colors[gameData.colorIndex];
	var strokeColor = gameData.complete == true ? gameSettings.colors[colorIndex].completeStroke : gameSettings.colors[colorIndex].drawStroke;
	gameData.fillCommand.style = strokeColor;
}

/*!
 * 
 * UPDATE GAME - This is the function that runs to loop game update
 * 
 */
function updateGame(){
	if(!gameData.paused && !$.editor.enable){
		if(!gameData.drawing && !gameData.complete){
			if(timeData.startDate == null){
				timeData.startDate = new Date();
			}

			timeData.nowDate = new Date();
			timeData.elapsedTime = Math.floor((timeData.nowDate.getTime() - timeData.startDate.getTime()));
			if(timeData.elapsedTime > 1000){
				timeData.startDate = new Date();

				if(gameData.strokesHistory.length > 0){
					var lastHistoryIndex = gameData.strokesHistory.length-1;
					animateDot(gameData.strokesHistory[lastHistoryIndex].eX,gameData.strokesHistory[lastHistoryIndex].eY, false);
				}
			}
		}
	}
}


/*!
 * 
 * END GAME - This is the function that runs for game end
 * 
 */
function endGame(){
	playSound('soundComplete');
	gameData.paused = true;

	gameData.colorIndex++;
	if(gameData.colorIndex > gameData.colors.length-1){
		gameData.colorIndex = 0;
		shuffle(gameData.colors);
	}
	
	gameData.revealLevel = false;
	gameData.levelNum++;
	if(gameData.levelNum >= gameData.levelCompleted && gameData.levelNum < levelSettings.length){
		gameData.revealLevel = true;
	}
	var nextLevel = gameData.levelNum+1;
	nextLevel = nextLevel > levelSettings.length ? levelSettings.length : nextLevel;
	findSelectPage(nextLevel);
	saveLevelData();
	
	TweenMax.to(puzzleContainer, .5, {scaleX:1.2, scaleY:1.2, overwrite:true, onComplete:function(){
		TweenMax.to(puzzleContainer, .5, {scaleX:1, scaleY:1, overwrite:true, onComplete:function(){
			TweenMax.to(gameContainer, 2, {overwrite:true, onComplete:function(){
				goPage('result')
			}});
		}});
	}});	
}

/*!
 * 
 * MILLISECONDS CONVERT - This is the function that runs to convert milliseconds to time
 * 
 */
function millisecondsToTimeGame(milli) {
	var milliseconds = milli % 1000;
	var seconds = Math.floor((milli / 1000) % 60);
	var minutes = Math.floor((milli / (60 * 1000)) % 60);
	
	if(seconds<10){
		seconds = '0'+seconds;  
	}
	
	if(minutes<10){
		minutes = '0'+minutes;  
	}
	
	return minutes+':'+seconds;
}

/*!
 * 
 * OPTIONS - This is the function that runs to toggle options
 * 
 */

function toggleOption(){
	if(optionsContainer.visible){
		optionsContainer.visible = false;
	}else{
		optionsContainer.visible = true;
	}
}


/*!
 * 
 * OPTIONS - This is the function that runs to mute and fullscreen
 * 
 */
function toggleSoundMute(con){
	buttonSoundOff.visible = false;
	buttonSoundOn.visible = false;
	toggleSoundInMute(con);
	if(con){
		buttonSoundOn.visible = true;
	}else{
		buttonSoundOff.visible = true;	
	}
}

function toggleMusicMute(con){
	buttonMusicOff.visible = false;
	buttonMusicOn.visible = false;
	toggleMusicInMute(con);
	if(con){
		buttonMusicOn.visible = true;
	}else{
		buttonMusicOff.visible = true;	
	}
}

function toggleFullScreen() {
  if (!document.fullscreenElement &&    // alternative standard method
      !document.mozFullScreenElement && !document.webkitFullscreenElement && !document.msFullscreenElement ) {  // current working methods
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen();
    } else if (document.documentElement.msRequestFullscreen) {
      document.documentElement.msRequestFullscreen();
    } else if (document.documentElement.mozRequestFullScreen) {
      document.documentElement.mozRequestFullScreen();
    } else if (document.documentElement.webkitRequestFullscreen) {
      document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
    }
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    }
  }
}

/*!
 * 
 * SHARE - This is the function that runs to open share url
 * 
 */
function share(action){
	gtag('event','click',{'event_category':'share','event_label':action});
	
	var loc = location.href
	loc = loc.substring(0, loc.lastIndexOf("/") + 1);
	
	var title = '';
	var text = '';
	
	title = shareTitle.replace("[SCORE]", playerData.score);
	text = shareMessage.replace("[SCORE]", playerData.score);
	
	var shareurl = '';
	
	if( action == 'twitter' ) {
		shareurl = 'https://twitter.com/intent/tweet?url='+loc+'&text='+text;
	}else if( action == 'facebook' ){
		shareurl = 'https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(loc+'share.php?desc='+text+'&title='+title+'&url='+loc+'&thumb='+loc+'share.jpg&width=590&height=300');
	}else if( action == 'google' ){
		shareurl = 'https://plus.google.com/share?url='+loc;
	}else if( action == 'whatsapp' ){
		shareurl = "whatsapp://send?text=" + encodeURIComponent(text) + " - " + encodeURIComponent(loc);
	}
	
	window.open(shareurl);
}