﻿let game_data = {
    'clear_storage': false, // if set true the progress resets
    'test_ad': true, // if set false test ad overlay will no appear
    'allowed_trials': 1, // how many attempts are there to continue the game by watching ads
    'urls': { // path urls object
		'audio': 'assets/audio/',
	},
    'ads': {'interstitial': { // configuration of ads
            'event_mult': {
                'level_lost': 0.75, 'level_win': 0.15,
                'level_start': 0, 'game_start': 0
            }
		},
        'rewarded': {}
	},
    // user data object. If saved data exists then here it will be stored.
    // Otherwise, local_user_data will be stored here
    'user_data': {}
}

let local_user_data = {
    'sound': 1, // if 0 sound will be disabled
    'music': 1, // if 0 music will be disabled
    'global_score': 0, // best score
    'old_global_score': 0 // best previos score
}

let gameOptions = {
    // random level background color
    bgColors: [0x62bd18, 0xff5300, 0xd21034, 0xff475c, 0x8f16b2, 0x588c7e, 0x8c4646],
    // hole width
    holeWidthRange: [80, 260],
    // wall range
    wallRange: [10, 50],
    // grow speed. The bigger value, the slower speed grow
    growTime: 1500
}