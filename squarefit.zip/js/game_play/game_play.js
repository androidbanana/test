const IDLE = 0;
const WAITING = 1;
const GROWING = 2;
let GamePlay = new Phaser.Class({
 
	Extends: Phaser.GameObjects.Container,   

	initialize:

	function GamePlay (scene)
	{
		this.scene = game_data['scene'];
		Phaser.GameObjects.Container.call(this, this.scene, 0, 0);        
		this.emitter = new Phaser.Events.EventEmitter();
        this.currentStageAdsWatched = 0;
        this.level_active = false;
        this.level_fail = false;
        this.level_started = false;
        this.allow_tap = false;
        this.button_mode = true;
	},

	init(params) {
        game_data['game_play'] = this;
        this.score = 0;
        
        // 定义超休闲游戏风格的配色方案
        this.colorSchemes = [
            0xFF6B6B, // 珊瑚红
            0x06D6A0, // 薄荷绿
            0xFEE440, // 柠檬黄
            0x00BBF9, // 亮蓝
            0xF15BB5, // 亮玫红
            0xFF9F1C, // 明亮的橙色
            0x9B5DE5  // 明亮的紫色
        ];
        
        // 用于记录上一次使用的颜色索引
        this.lastColorIndex = -1;
        
        let tintColor = this.getNextColor();
        this.scene.cameras.main.setBackgroundColor(tintColor);
        this.leftSquare = this.scene.add.sprite(0, loading_vars['H'], "common1", "base");
        this.leftSquare.setOrigin(1, 1);
        this.add(this.leftSquare);
        this.rightSquare = this.scene.add.sprite(loading_vars['W'], loading_vars['H'], "common1", "base");
        this.rightSquare.setOrigin(0, 1);
        this.add(this.rightSquare);
        this.leftWall = this.scene.add.sprite(0, loading_vars['H'] - this.leftSquare.height, "common1", "top");
        this.leftWall.setOrigin(1, 1);
        this.add(this.leftWall);
        this.rightWall = this.scene.add.sprite(loading_vars['W'], loading_vars['H'] - this.rightSquare.height, "common1", "top");
        this.rightWall.setOrigin(0, 1);
        this.add(this.rightWall);
        this.square = this.scene.add.sprite(loading_vars['W'] / 2, -400, "common1", "square");
        this.square.successful = 0;
        this.square.setScale(0.2);
        this.add(this.square);
        this.squareText = this.scene.add.bitmapText(loading_vars['W'] / 2, -400, "font", this.score, 120);
        this.squareText.setOrigin(0.5);
        this.squareText.setScale(0.4);
        this.squareText.setTint(tintColor);
        this.add(this.squareText);
        this.levelText = this.scene.add.bitmapText(loading_vars['W'] / 2, 50, "font", "", 45);
        this.levelText.setOrigin(0.5, 0);
        this.add(this.levelText);
        this.scoreText = this.scene.add.bitmapText(loading_vars['W'] / 2, loading_vars['H'] / 2 - 20, "font2", "", 150);
        this.scoreText.alpha = 0.7;
        this.scoreText.setOrigin(0.5);
        this.add(this.scoreText);
        this.input_overlay = new Phaser.GameObjects.Image(this.scene, loading_vars['W'] / 2, loading_vars['H'] / 2,'dark_overlay');
        this.input_overlay.alpha = 0.01;
        this.input_overlay.setInteractive();
        this.add(this.input_overlay);

        this.create_sound_buttons();
        this.update_level();

        if (this.button_mode) {
            this.input_overlay.on("pointerdown", () => {
                this.pre_func(() => {
                    this.grow();
                });
            }, this);
            this.input_overlay.on("pointerup", () => {
                this.pre_func(() => {
                    this.stop();
                });
            }, this);
            
            // 添加开始按钮，位置上移
            this.button_start = new CustomButton(game_data['scene'], loading_vars['W'] / 2, loading_vars['H'] / 2 - 50, this.handler_start, 'common1'
            , 'btn', 'btn', 'btn', this, null, null, 1);
            this.add(this.button_start);
            this.button_start_txt = this.scene.add.bitmapText(0, 6, "font", "Start", 50);
            this.button_start_txt.setOrigin(0.5);
            this.button_start.add(this.button_start_txt);

            // 添加Best Score文本，使用和游戏结束界面一致的样式
            this.bestScoreTitle = this.scene.add.bitmapText(loading_vars['W'] / 2, loading_vars['H'] / 2 + 50, "font", "BEST SCORE", 60);
            this.bestScoreTitle.setOrigin(0.5);
            this.add(this.bestScoreTitle);
            
            this.bestScoreValue = this.scene.add.bitmapText(loading_vars['W'] / 2, loading_vars['H'] / 2 + 130, "font", game_data['user_data']['global_score'], 100);
            this.bestScoreValue.setOrigin(0.5);
            this.add(this.bestScoreValue);
        }
        else {
            this.input_overlay.on("pointerdown", this.grow, this);
            this.input_overlay.on("pointerup", this.stop, this);
        }
        this.gameMode = IDLE;

    },
    handler_start() {
        this.level_started = true;
        this.infoGroup.setVisible(true);
        this.button_start.setVisible(false);
        // 隐藏Best Score显示
        if (this.bestScoreTitle) this.bestScoreTitle.setVisible(false);
        if (this.bestScoreValue) this.bestScoreValue.setVisible(false);
        setTimeout(() => { this.allow_tap = true; }, 400);
        game_data['utils'].check_ads('level_start');
    },

    pre_func(on_complete = () => {}) {
        if (this.level_started && this.allow_tap) {
            on_complete();
        }
    },

    restart_level() {
        this.allow_tap = false;
        this.score = 0;
        this.currentStageAdsWatched = 0;
        this.level_active = false;
        this.level_fail = false;
        this.square.successful = 0;
        this.squareText.text = this.score;
        this.levelText.text = "";
        this.scoreText.text = "";
        
        // 显示开始按钮和Best Score
        if (this.button_mode) {
            this.button_start.setVisible(true);
            this.infoGroup.setVisible(false);
            this.level_started = false;
            
            if (this.bestScoreTitle) {
                this.bestScoreTitle.setVisible(true);
                // 更新最高分显示
                this.bestScoreValue.text = game_data['user_data']['global_score'];
                this.bestScoreValue.setVisible(true);
            }
        }
        
        // 在重启关卡时更改颜色
        this.updateSceneColor();
        
        let tintColor = this.getNextColor();
        this.scene.cameras.main.setBackgroundColor(tintColor);
        this.squareText.setTint(tintColor);
        this.update_level();
    },

    update_level(){
        let holeWidth = Phaser.Math.Between(gameOptions.holeWidthRange[0], gameOptions.holeWidthRange[1]);
        let wallWidth = Phaser.Math.Between(gameOptions.wallRange[0], gameOptions.wallRange[1]);
        this.placeWall(this.leftSquare, (loading_vars['W'] - holeWidth) / 2);
        this.placeWall(this.rightSquare, (loading_vars['W'] + holeWidth) / 2);
        this.placeWall(this.leftWall, (loading_vars['W'] - holeWidth) / 2 - wallWidth);
        this.placeWall(this.rightWall, (loading_vars['W'] + holeWidth) / 2 + wallWidth);
        let squareTween = this.scene.tweens.add({
            targets: [this.square, this.squareText],
            y: 150,
            scaleX: 0.2,
            scaleY: 0.2,
            angle: 50,
            duration: 500,
            ease: "Cubic.easeOut",
            callbackScope: this,
            onComplete: function(){
                this.rotateTween = this.scene.tweens.add({
                    targets: [this.square, this.squareText],
                    angle: 40,
                    duration: 300,
                    yoyo: true,
                    repeat: -1
                });
                if(this.square.successful == 0){
                    this.addInfo(holeWidth, wallWidth);
                }
                this.gameMode = WAITING;
            }
        })
    },
    placeWall(target, posX){
        this.scene.tweens.add({
            targets: target,
            x: posX,
            duration: 500,
            ease: "Cubic.easeOut"
        });
    },
    grow(){
        if(this.gameMode == WAITING){
            this.gameMode = GROWING;
            if(this.square.successful == 0){
                this.infoGroup.toggleVisible();
            }
            this.growTween = this.scene.tweens.add({
                targets: [this.square, this.squareText],
                scaleX: 1,
                scaleY: 1,
                duration: gameOptions.growTime
            });
            
            if (!this.level_active) {
                game_data['utils'].game_play_start();
                this.level_active = true;
            }
        }
    },
    stop(){
        if(this.gameMode == GROWING){
            this.gameMode = IDLE;
            this.growTween.stop();
            this.rotateTween.stop();
            this.rotateTween = this.scene.tweens.add({
                targets: [this.square, this.squareText],
                angle: 0,
                duration:300,
                ease: "Cubic.easeOut",
                callbackScope: this,
                onComplete: function(){
                    if(this.square.displayWidth <= this.rightSquare.x - this.leftSquare.x){
                        
                        this.scene.tweens.add({
                            targets: [this.square, this.squareText],
                            y: loading_vars['H'] + this.square.displayWidth,
                            duration:600,
                            ease: "Cubic.easeIn",
                            callbackScope: this,
                            onComplete: function(){
                                game_data['audio_manager'].sound_event({'play': true, 'sound_name': 'woosh'});
                                this.levelText.text = Phaser.Utils.Array.GetRandom(["Oh no!!!", "Oops, try again!", "Uh-oh, not quite there.", "Better luck next time!", "Close, but not quite!", "Almost, keep trying!"]);
                                this.gameOver();
                            }
                        })
                    }
                    else{
                        if(this.square.displayWidth <= this.rightWall.x - this.leftWall.x){
                            this.fallAndBounce(true);
                        }
                        else{
                            this.fallAndBounce(false);
                        }
                    }
                }
            });
        }
    },
    fallAndBounce(success){
        let destY = loading_vars['H'] - this.leftSquare.displayHeight - this.square.displayHeight / 2;
        let message = Phaser.Utils.Array.GetRandom(["Yeah!!!", "Awesome!", "Great job!", "Well done!", "Fantastic!", "Amazing!"]);
        if(success){
            this.square.successful++;
            this.score++;
            this.squareText.text = this.score;  // 更新方块上的分数
            // 在成功得分后更改颜色
            this.updateSceneColor();
        }
        else{
            destY = loading_vars['H'] - this.leftSquare.displayHeight - this.leftWall.displayHeight - this.square.displayHeight / 2;
            message = Phaser.Utils.Array.GetRandom(["Oh no!!!", "Oops, try again!", "Uh-oh, not quite there.", "Better luck next time!", "Close, but not quite!", "Almost, keep trying!"]);
        }
        setTimeout(() => { game_data['audio_manager'].sound_event({'play': true, 'sound_name': 'jump'}); }, 300)
        
        this.scene.tweens.add({
            targets: [this.square, this.squareText],
            y: destY,
            duration:600,
            ease: "Bounce.easeOut",
            callbackScope: this,
            onComplete: () => {
                
                this.levelText.text = message;
                if(!success){
                    this.gameOver();
                }
                else{
                    this.scoreText.text = "";
                    this.scene.time.addEvent({
                        delay: 1000,
                        callback: () => {    
                            this.levelText.text = "";
                            game_data['utils'].check_ads('level_win');
                            this.update_level();
                        },
                        callbackScope: this
                    });
                }
            }
        })
    },
    addInfo(holeWidth, wallWidth){
        this.infoGroup = this.scene.add.group();
        let targetSquare = this.scene.add.sprite(loading_vars['W'] / 2, loading_vars['H'] - this.leftSquare.displayHeight, "common1", "square");
        targetSquare.displayWidth = holeWidth + wallWidth;
        targetSquare.displayHeight = holeWidth + wallWidth;
        targetSquare.alpha = 0.3;
        targetSquare.setOrigin(0.5, 1);
        this.add(targetSquare);
        this.infoGroup.add(targetSquare);
        let targetText = this.scene.add.bitmapText(loading_vars['W'] / 2, targetSquare.y - targetSquare.displayHeight, "font", "Land here", 48);
        targetText.setOrigin(0.5, 1);
        this.add(targetText);
        this.infoGroup.add(targetText);
        let holdText = this.scene.add.bitmapText(loading_vars['W'] / 2, 250 - 20, "font", "Tap and Hold to grow", 40);
        holdText.setOrigin(0.5, 0);
        this.add(holdText);
        this.infoGroup.add(holdText);
        let releaseText = this.scene.add.bitmapText(loading_vars['W'] / 2, 300 - 20, "font", "Release to drop", 40);
        releaseText.setOrigin(0.5, 0);
        this.add(releaseText);
        this.infoGroup.add(releaseText);
        
        // 移除这里的奖杯和分数显示
        this.infoGroup.setVisible(false);
    },
    gameOver(){
        if (this.score === 0) this.restart_level();
        else this.level_failed();
    },

    show_gameplay(obj) {
        if (obj['init']) game_data['utils'].check_ads('game_start');
    },

    update(){

    },

    pause_timer() {
        if (this.level_active) {
            // if (this.timerEvent) this.timerEvent.paused = true;
        }
    },

    resume_timer() {
        if (this.level_active) {
            // if (this.timerEvent) this.timerEvent.paused = false;
        }
    },

    create_sound_buttons() {
        this.buttonsGroup = this.scene.add.group();

        this.button_music = new Phaser.GameObjects.Container(this.scene, 0, 0);
        this.button_music.scale = 0.8;
        this.add(this.button_music);
        this.button_music_on = new CustomButton(this.scene, 60, 60, this.handler_music, 'common1', 'music_on', 'music_on', 'music_on',  this);
        this.button_music.add(this.button_music_on);
        this.button_music_off = new CustomButton(this.scene, 60, 60, this.handler_music, 'common1', 'music_off', 'music_off', 'music_off', this);
        this.button_music.add(this.button_music_off);
        this.buttonsGroup.add(this.button_music);
         
        this.button_sound = new Phaser.GameObjects.Container(this.scene, 0, 0);
        this.button_sound.scale = 0.8;
        this.add(this.button_sound);
        this.button_sound_on = new CustomButton(this.scene, 60, 170, this.handler_sound, 'common1', 'sound_on', 'sound_on', 'sound_on', this);
        this.button_sound.add(this.button_sound_on);
        this.button_sound_off = new CustomButton(this.scene, 60, 170, this.handler_sound, 'common1', 'sound_off', 'sound_off', 'sound_off', this);
        this.button_sound.add(this.button_sound_off);
        this.buttonsGroup.add(this.button_sound);
        
        this.update_buttons();
    },

    handler_music(params) {	
        game_data['user_data']['music'] = 1 - game_data['user_data']['music'];
        this.update_buttons();
        game_request.request({'set_options': true, 'sound': game_data['user_data']['sound'] , 'music': game_data['user_data']['music']}, function(){});
        game_data['audio_manager'].update_volume();
    },
    
    handler_sound(params) {	
        game_data['user_data']['sound'] = 1 - game_data['user_data']['sound'];
        this.update_buttons();
        game_request.request({'set_options': true, 'sound': game_data['user_data']['sound'] , 'music': game_data['user_data']['music']}, function(){});
        game_data['audio_manager'].update_volume();
    },

    update_buttons() {
        this.button_music_on.visible = game_data['user_data']['music'] == 1;
        this.button_music_off.visible = game_data['user_data']['music'] == 0;
        
        this.button_sound_on.visible = game_data['user_data']['sound'] == 1;
        this.button_sound_off.visible = game_data['user_data']['sound'] == 0;
    },

    level_failed() {
        if (allow_rewarded_ads && this.currentStageAdsWatched < game_data['allowed_trials']) {
            this.level_fail = true;
            this.level_active = false;
            this.emitter.emit('EVENT', {
                'event': 'show_window',
                'window_id': 'level_failed',
                'score': this.score,
                'currentStageAdsWatched': this.currentStageAdsWatched
            });
        }
        else {
            game_data['utils'].game_play_stop();
            game_request.request({'level_failed': true, 'global_score': this.score }, params => {
                if (params['new_score'] && 'global_score' in params) {
                    game_data['utils'].update_score(params['global_score']);
                    game_data['utils'].happy_moment();
                }
                if (params['new_stage'] && 'levels_passed' in params) game_data['utils'].update_level(params['levels_passed']);
                if (this.score > 0) game_data['utils'].check_ads('level_lost');
                this.restart_level();
            });

        }
        game_data['audio_manager'].sound_event({'play': true, 'sound_name': 'gameover'});
    },

    continue_game() {
        this.level_fail = false;
        this.levelText.text = "";
        this.update_level();
    },

    rewarded_ad_watched() {
        this.currentStageAdsWatched++;
    },
    
    // 获取下一个颜色，简单地随机选择一个不同的颜色
    getNextColor() {
        let newIndex;
        do {
            newIndex = Math.floor(Math.random() * this.colorSchemes.length);
        } while (newIndex === this.lastColorIndex);
        
        this.lastColorIndex = newIndex;
        return this.colorSchemes[newIndex];
    },

    // 更新场景颜色
    updateSceneColor() {
        let newColor = this.getNextColor();
        
        // 创建颜色渐变动画
        this.scene.tweens.addCounter({
            from: 0,
            to: 100,
            duration: 800,
            ease: 'Sine.easeInOut',
            onUpdate: (tween) => {
                const progress = tween.getValue() / 100;
                
                // 获取当前背景色
                const currentColor = this.scene.cameras.main.backgroundColor.color;
                
                // 计算渐变中的颜色
                const r = Phaser.Math.Linear((currentColor >> 16) & 0xff, (newColor >> 16) & 0xff, progress);
                const g = Phaser.Math.Linear((currentColor >> 8) & 0xff, (newColor >> 8) & 0xff, progress);
                const b = Phaser.Math.Linear(currentColor & 0xff, newColor & 0xff, progress);
                
                const interpolatedColor = (r << 16) | (g << 8) | b;
                
                // 只对背景和当前分数应用渐变颜色
                this.scene.cameras.main.setBackgroundColor(interpolatedColor);
                this.squareText.setTint(interpolatedColor);
            }
        });
    },
    handler_success() {
        this.score++;
        let message = Phaser.Utils.Array.GetRandom(["Perfect!", "Awesome!", "Great job!", "Well done!", "Fantastic!", "Amazing!"]);
        this.levelText.text = message;
        this.wall_tween.stop();
        
        // 在得分后更改颜色
        this.updateSceneColor();
        
        this.scene.tweens.add({
            targets: [this.wall, this.hole],
            alpha: 0,
            duration: 200,
            onComplete: () => {
                this.scene.tweens.add({
                    targets: this.levelText,
                    alpha: 0,
                    duration: 200,
                    delay: 500,
                    onComplete: () => {
                        this.levelText.text = "";
                        game_data['utils'].check_ads('level_win');
                        this.update_level();
                    }
                });
            }
        });
    }
});