let LevelFailed = new Phaser.Class({
 
	Extends: Phaser.GameObjects.Container,   

	initialize:

	function LevelFailed()
    {
        this.scene = game_data['scene'];
        Phaser.GameObjects.Container.call(this, this.scene, 0, 0);        
        this.emitter = new Phaser.Events.EventEmitter();
    },


init(params) {
	this.paid_replay = false;
	this.money_pt = params['money_pt'];
	this.score = params['score'];

	this.btn_cont = new Phaser.GameObjects.Container(this.scene, 0, 0);
	this.add(this.btn_cont);

	this.text1 = this.scene.add.bitmapText(0, -250, "font", "YOUR SCORE", 60);
	this.text2 = this.scene.add.bitmapText(0, -170, "font", this.score, 100);
	this.text3 = this.scene.add.bitmapText(0, -50, "font", "BEST SCORE", 60);
	this.text4 = this.scene.add.bitmapText(0, 30, "font", game_data.user_data.global_score, 100);
	this.text5 = this.scene.add.bitmapText(0, 5, "font", "Continue", 35);
	this.text1.setOrigin(0.5);
	this.text2.setOrigin(0.5);
	this.text3.setOrigin(0.5);
	this.text4.setOrigin(0.5);
	this.text5.setOrigin(0.5);
	this.add(this.text1);
	this.add(this.text2);
	this.add(this.text3);
	this.add(this.text4);
	
	this.button_play = new CustomButton(game_data['scene'], 0, 180, this.handler_cancel, 'common1'
	, 'btn', 'btn', 'btn', this, null, null, 1);

	this.btn_cont.add(this.button_play);
	this.button_play.add(this.text5);

	this.jump_anim = game_data['scene'].tweens.add({
		targets: this.button_play,
		scale: 1.1,
		duration: 150,
		delay: 650,
		repeat: 2,
		yoyo: true
	});
},

pause() {
},

resume() {
},

handler_replay() {
},

handler_continue() {
	this.handler_close();
},

handler_cancel() {
	game_request.request({'level_failed': true, 'global_score': this.score }, params => {
		if (params['new_score'] && 'global_score' in params) {
			game_data['utils'].update_score(params['global_score']);
			game_data['utils'].happy_moment();
		}
		if (params['new_stage'] && 'levels_passed' in params) game_data['utils'].update_level(params['levels_passed']);
		this.emitter.emit('EVENT', {'event': 'restart_level'});
		game_data['utils'].game_play_stop();
		this.handler_close();
	});
},

handler_close(params) {
	if (!this.closed) {
		this.closed = true;
		this.close_window();
	}
	
},

close_window(event = {}) {
	game_data['utils'].hide_tip();
	this.emitter.emit('EVENT', {'event': 'window_close'});
},	
});